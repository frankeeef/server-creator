#-----[ CREATE PROPERTIES ]-----#

class property:
    seed = "seed"
    ip = "ip"
    gamemode = "gm"
    difficulty = "diff"
    hardcore = "hardcore"
    nether = "nether"
    server_port = "server_port"
    world_name = "world_name"
    enable_command_block = "enable_command_blocks"
    pvp = "pvp"
    max_players = "max_players"
    render_distance = "render_distance"
    spawn_protection = "spawn_protection"
    whitelist = "whitelist"
    simulation_distance = "simulation_distance"
    motd = "motd"

def generate_properties(properties: dict):
    return (
        f"""
level-seed={properties[property.seed]}
server-ip={properties[property.ip]}
motd={properties[property.motd]}
gamemode={properties[property.gamemode]}
hardcore={properties[property.hardcore]}
difficulty={properties[property.difficulty]}
allow-nether={properties[property.nether]}
server-port={properties[property.server_port]}
level-name={properties[property.world_name]}
enable-command-block={properties[property.enable_command_block]}
pvp={properties[property.pvp]}
max-players{properties[property.max_players]}
view-distance={properties[property.render_distance]}
spawn-protection={properties[property.spawn_protection]}
simulation-distance={properties[property.simulation_distance]}
white-list={properties[property.whitelist]}
        """
    )