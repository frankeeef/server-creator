from colorama import Style, Fore
import sys

class weight:
    bold = Style.BRIGHT
    normal = Style.NORMAL
    light = Style.DIM
class color:
    black = Fore.BLACK
    red = Fore.RED
    green = Fore.GREEN
    yellow = Fore.YELLOW
    blue = Fore.BLUE
    magenta = Fore.MAGENTA
    cyan = Fore.CYAN
    white = Fore.WHITE
    reset = Fore.RESET
    
#-----[FUNCTIONS]-----#
def listToString(s):
    str1 = " "
    return (str1.join(s))

def stylise(strText, strEmphasis, strColor):
    return strColor + strEmphasis + strText + Style.RESET_ALL

def noticePrint(noticer, color, noticee):
    print(color + Style.BRIGHT + f"{noticer}: " + Style.RESET_ALL + noticee + Style.RESET_ALL)

def argCheck(argInt, argVal):
    try:
        return sys.argv[argInt] == argVal
    except:
        return False

def argVal(argInt):
    try:
        return sys.argv[argInt]
    except:
        return