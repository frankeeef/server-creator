import sys
from time import sleep
from progressbar import progressbar
import random
from colorama import Fore, Style
from functions import *
import socket
from properties_functionality import property, generate_properties
    
hostname = socket.gethostname()
ip = socket.gethostbyname(hostname)

#-----[ MAIN LOOP ]-----#
if argCheck(1, "update"):
    print(Fore.RED + Style.BRIGHT + "Update: " + Style.RESET_ALL + "Beginning" + Style.RESET_ALL)
    for i in progressbar(range(563)):
        sleep(random.uniform(0.00,0.03))
    print(Fore.RED + Style.BRIGHT + "Update: " + Style.RESET_ALL + "Complete" + Style.RESET_ALL)
elif argCheck(1, "game"):
    if argCheck(2, "mc"):
        if argCheck(3, "server"):
            if argCheck(4, "port"):
                port = argVal(5)
            elif argCheck(4, "create"):
                print(Fore.GREEN + Style.BRIGHT + "Creating Minecraft Server: " + Style.RESET_ALL + "Beginning" + Style.RESET_ALL)
                for i in progressbar(range(563)):
                    sleep(random.uniform(0.00,0.00))
                properties = (generate_properties({
    property.seed: input("Enter seed > "),
    property.difficulty: input("Enter difficulty > "),
    property.world_name: input("Enter world name > "),
    property.enable_command_block: input("Enable command blocks (true or false) > "),
    property.ip: input(f"Enter ip (Your ip is {ip}) > "),
    property.max_players: input("Enter max players > "),
    property.gamemode: input("Enter gamemode > "),
    property.hardcore: input("Enable hardcore (true or false) > "),
    property.motd: input("Enter MOTD > "),
    property.nether: input("Enable Nether (true or false) > "),
    property.pvp: input("Enable PVP (true or false) > "),
    property.render_distance: input("Enter render distance > "),
    property.simulation_distance: input("Enter simulation distance > "),
    property.spawn_protection: input("Enter spawn protection > "),
    property.whitelist: input("Enable whitelist (true or false) > "),
    property.server_port: input("Enter server port (recommended is 25565) > "),
}))
                print(properties)
                print(Fore.GREEN + Style.BRIGHT + "Creating Minecraft Server: " + Style.RESET_ALL + "Complete" + Style.RESET_ALL)
            elif argCheck(4, "startat"):
                for i in progressbar(range(563)):
                    sleep(0.01)
                noticePrint("[MC Server]", color.green, f"Server opened at IP: " + color.red + weight.bold + socket.gethostbyname(socket.gethostname()) + color.reset + weight.normal + " Port: "+ color.red + weight.bold + argVal(5) + color.reset)
